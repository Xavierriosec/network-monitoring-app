# network-monitoring-app
La aplicación mostraría un dashboard donde podrías ver gráficas de datos de flujo y métricas en tiempo real. Grafana presentará gráficos personalizados en base a tus métricas y los flujos de red, mientras que el frontend en React permitiría agregar y gestionar dispositivos.
